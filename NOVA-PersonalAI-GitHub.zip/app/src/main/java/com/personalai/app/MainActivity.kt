package com.personalai.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

data class ChatMessage(val role: String, val text: String)

class MainActivity : ComponentActivity() {
    private val client = OkHttpClient()
    private var tts: TextToSpeech? = null
    private val prefs by lazy { getSharedPreferences("nova_memory", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { tts?.language = Locale("es", "ES") }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFF7657FF),
                secondary = Color(0xFF55C7FF),
                background = Color(0xFF06080E),
                surface = Color(0xFF101522)
            )) { NovaApp() }
        }
    }

    private fun loadMemories(): MutableList<String> {
        val raw = prefs.getString("memories", "[]") ?: "[]"
        val arr = JSONArray(raw)
        return MutableList(arr.length()) { i -> arr.getString(i) }
    }

    private fun saveMemories(list: List<String>) {
        val arr = JSONArray()
        list.distinct().take(80).forEach { arr.put(it) }
        prefs.edit().putString("memories", arr.toString()).apply()
    }

    private fun learnFrom(text: String, memories: MutableList<String>): String? {
        val t = text.trim()
        val l = t.lowercase(Locale.getDefault())
        val starts = listOf(
            "me gusta ", "me encanta ", "no me gusta ", "prefiero ",
            "mi coche ", "mi auto ", "mi trabajo ", "soy ", "tengo ",
            "quiero ", "odio ", "mi nombre ", "vivo en ",
            "estoy buscando ", "me interesa "
        )
        if (t.length >= 8 && starts.any { l.startsWith(it) }) {
            if (memories.none { it.equals(t, ignoreCase = true) }) {
                memories.add(0, t.removeSuffix("."))
                saveMemories(memories)
                return t
            }
        }
        return null
    }

    @Composable
    private fun NovaApp() {
        var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
        var input by remember { mutableStateOf("") }
        var messages by remember { mutableStateOf(listOf<ChatMessage>()) }
        var memories by remember { mutableStateOf(loadMemories()) }
        var busy by remember { mutableStateOf(false) }
        var listening by remember { mutableStateOf(false) }
        var settings by remember { mutableStateOf(false) }

        val voice = rememberLauncherForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            listening = false
            result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()?.let { input = it }
        }

        fun send() {
            val q = input.trim()
            if (q.isBlank() || busy) return
            input = ""
            learnFrom(q, memories)
            memories = loadMemories()
            messages = messages + ChatMessage("user", q)
            busy = true
            lifecycleScope.launch {
                val answer = withContext(Dispatchers.IO) {
                    askOpenAI(apiKey, q, messages, memories)
                }
                messages = messages + ChatMessage("assistant", answer)
                busy = false
                if (answer.isNotBlank())
                    tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "nova-answer")
            }
        }

        if (settings) {
            SettingsScreen(
                apiKey, { apiKey = it; prefs.edit().putString("api_key", it).apply() },
                memories,
                { i -> memories = memories.toMutableList().also { it.removeAt(i) }; saveMemories(memories) },
                { settings = false }
            )
            return
        }

        Scaffold(
            containerColor = Color(0xFF06080E),
            topBar = {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(false, busy || listening)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("NOVA", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text(
                            if (listening) "Escuchando…" else if (busy) "Pensando…" else "Tu IA personal",
                            color = Color.Gray, fontSize = 12.sp
                        )
                    }
                    IconButton({ settings = true }) { Icon(Icons.Default.Settings, "Configuración") }
                }
            },
            bottomBar = {
                Row(Modifier.fillMaxWidth().padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton({
                        listening = true
                        voice.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla con NOVA")
                        })
                    }) { Icon(Icons.Default.Mic, "Voz") }
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Escribe un mensaje…") },
                        shape = RoundedCornerShape(24.dp), maxLines = 4
                    )
                    IconButton({ send() }, enabled = !busy) { Icon(Icons.Default.Send, "Enviar") }
                }
            }
        ) { pad ->
            Column(Modifier.fillMaxSize().padding(pad)) {
                // Main visual requirement: avatar first, conversation directly underneath.
                Box(
                    Modifier.fillMaxWidth().height(285.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Avatar(true, busy || listening)
                    if (messages.isEmpty()) {
                        Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Hola, soy NOVA", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                            Text("Habla conmigo por texto o voz", color = Color.Gray, fontSize = 13.sp)
                        }
                    }
                }
                HorizontalDivider(color = Color(0xFF202638))
                if (messages.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Cuéntame cosas sobre ti.\nIré aprendiendo tus preferencias.",
                            color = Color.Gray, fontSize = 14.sp)
                    }
                } else {
                    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp),
                        contentPadding = PaddingValues(vertical = 10.dp)) {
                        itemsIndexed(messages) { _, m -> ChatBubble(m) }
                        if (busy) item { Text("NOVA está pensando…", color = Color.Gray,
                            Modifier.padding(12.dp)) }
                    }
                }
            }
        }
    }

    @Composable
    private fun Avatar(large: Boolean, active: Boolean) {
        val transition = rememberInfiniteTransition(label = "nova")
        val scale by transition.animateFloat(
            1f, if (active) 1.05f else 1.018f,
            infiniteRepeatable(tween(if (active) 420 else 1500, easing = FastOutSlowInEasing),
                RepeatMode.Reverse), label = "pulse"
        )
        val size = if (large) 245 else 56
        Image(
            painter = painterResource(R.drawable.nova_avatar),
            contentDescription = "Avatar extraterrestre de NOVA",
            modifier = Modifier.size(size.dp).scale(scale).clip(CircleShape),
            contentScale = ContentScale.Crop
        )
    }

    @Composable
    private fun ChatBubble(m: ChatMessage) {
        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp),
            horizontalArrangement = if (m.role == "user") Arrangement.End else Arrangement.Start) {
            Surface(
                color = if (m.role == "user") Color(0xFF49368D) else Color(0xFF151A28),
                shape = RoundedCornerShape(18.dp)
            ) { Text(m.text, Modifier.padding(13.dp), color = Color.White, fontSize = 14.sp) }
        }
    }

    @Composable
    private fun SettingsScreen(
        key: String, onKey: (String) -> Unit, memories: List<String>,
        delete: (Int) -> Unit, close: () -> Unit
    ) {
        Column(Modifier.fillMaxSize().background(Color(0xFF06080E)).padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(close) { Icon(Icons.Default.ArrowBack, "Volver") }
                Text("Configuración", fontSize = 23.sp)
            }
            Spacer(Modifier.height(18.dp))
            Text("API key")
            OutlinedTextField(key, onKey, Modifier.fillMaxWidth(),
                placeholder = { Text("sk-…") },
                visualTransformation = PasswordVisualTransformation(), singleLine = true)
            Spacer(Modifier.height(22.dp))
            Text("🧠 Memoria personal", fontSize = 19.sp)
            Text("NOVA guarda automáticamente algunas preferencias detectadas.",
                color = Color.Gray, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            LazyColumn {
                itemsIndexed(memories) { i, memory ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text("• $memory", Modifier.weight(1f), fontSize = 13.sp)
                        IconButton({ delete(i) }) { Icon(Icons.Default.Delete, "Borrar") }
                    }
                }
            }
        }
    }

    private fun askOpenAI(key: String, question: String, history: List<ChatMessage>, memories: List<String>): String {
        if (key.isBlank()) return "Configura tu API key en ⚙️ para poder hablar conmigo."
        val mem = if (memories.isEmpty()) "Sin recuerdos todavía." else memories.joinToString("\n") { "- $it" }
        val input = JSONArray()
        history.takeLast(14).forEach {
            input.put(JSONObject().put("role", it.role).put("content", it.text))
        }
        val body = JSONObject()
            .put("model", "gpt-5.6-luna")
            .put("instructions", """Eres NOVA, una IA personal cercana, inteligente y útil.
Habla en español salvo que el usuario use otro idioma. Usa la memoria para adaptar tus respuestas.
Nunca inventes recuerdos. Sé directa y natural.

MEMORIA DEL USUARIO:
$mem""")
            .put("input", input)

        val request = Request.Builder().url("https://api.openai.com/v1/responses")
            .addHeader("Authorization", "Bearer $key")
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()

        return try {
            client.newCall(request).execute().use { r ->
                val raw = r.body?.string().orEmpty()
                if (!r.isSuccessful) return "Error de API (${r.code}). Revisa la API key."
                val json = JSONObject(raw)
                json.optString("output_text").ifBlank { extract(json) }
            }
        } catch (e: Exception) {
            "No he podido conectar con la IA: ${e.message ?: "error de red"}"
        }
    }

    private fun extract(json: JSONObject): String {
        val output = json.optJSONArray("output") ?: return "Respuesta vacía."
        val result = StringBuilder()
        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val part = content.optJSONObject(j) ?: continue
                result.append(part.optString("text"))
            }
        }
        return result.toString().ifBlank { "Respuesta vacía." }
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}
