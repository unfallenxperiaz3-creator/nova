package com.unfallen.personalai

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { PersonalAIApp() } }
}

data class ChatMessage(val role: String, val text: String)

class AiViewModel : ViewModel() {
    private val client = OkHttpClient()
    var apiKey by mutableStateOf(""); private set
    var messages by mutableStateOf(listOf<ChatMessage>()); private set
    var memories by mutableStateOf(listOf<String>()); private set
    var input by mutableStateOf("")
    var busy by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    private var sentCount = 0
    private var context: Context? = null

    fun init(c: Context) {
        if (context != null) return
        context = c.applicationContext
        val p = c.getSharedPreferences("personal_ai", Context.MODE_PRIVATE)
        apiKey = p.getString("api_key", "") ?: ""
        memories = p.getStringSet("memories", emptySet())?.toList()?.sorted() ?: emptyList()
        val raw = p.getString("messages", "[]") ?: "[]"
        val a = JSONArray(raw); messages = (0 until a.length()).map { val o=a.getJSONObject(it); ChatMessage(o.getString("role"), o.getString("text")) }
    }
    fun saveKey(k:String) { apiKey=k.trim(); context?.getSharedPreferences("personal_ai",0)?.edit()?.putString("api_key",apiKey)?.apply() }
    fun addMemory(m:String) { if(m.isBlank()) return; memories=(memories+m.trim()).distinct().takeLast(100); persist() }
    fun deleteMemory(m:String) { memories=memories.filterNot{it==m}; persist() }
    fun clearAll() { messages=emptyList(); memories=emptyList(); persist() }
    private fun persist(){ context?.getSharedPreferences("personal_ai",0)?.edit()?.putStringSet("memories",memories.toSet())?.putString("messages", JSONArray().apply{messages.forEach{put(JSONObject().put("role",it.role).put("text",it.text))}}.toString())?.apply() }

    fun send() {
        val text=input.trim(); if(text.isEmpty()||busy) return
        if(apiKey.isBlank()){ error="Introduce tu API key en Ajustes."; return }
        messages=messages+ChatMessage("user",text); input=""; busy=true; error=null; persist()
        viewModelScope.launch {
            try {
                val reply=callModel(text)
                messages=messages+ChatMessage("assistant",reply); persist(); sentCount++
                if(sentCount%5==0) extractMemory()
            } catch(e:Exception){ error=e.message ?: "Error desconocido" }
            finally{ busy=false }
        }
    }
    private suspend fun callModel(userText:String):String = withContext(Dispatchers.IO) {
        val memory=memories.joinToString("\n") { "- $it" }.ifBlank{"(Todavía no hay recuerdos aprendidos.)"}
        val recent=messages.takeLast(12).joinToString("\n") { "${it.role}: ${it.text}" }
        val instructions="""Eres Personal AI, un asistente personal cálido, directo y útil. Tu objetivo es responder como un ChatGPT personal que conoce progresivamente al usuario. Usa los recuerdos solo como contexto; no inventes datos. Si un recuerdo contradice lo que el usuario acaba de decir, prioriza lo nuevo. No menciones la memoria salvo que sea relevante. Responde en español salvo que el usuario pida otro idioma.\n\nMEMORIA DEL USUARIO:\n$memory\n\nCONVERSACIÓN RECIENTE:\n$recent"""
        val body=JSONObject().put("model","gpt-5.6-luna").put("instructions",instructions).put("input",userText).put("max_output_tokens",1200)
        val req=Request.Builder().url("https://api.openai.com/v1/responses").addHeader("Authorization","Bearer $apiKey").addHeader("Content-Type","application/json").post(body.toString().toRequestBody("application/json".toMediaType())).build()
        client.newCall(req).execute().use { r -> val raw=r.body?.string().orEmpty(); if(!r.isSuccessful) throw Exception("API ${r.code}: ${JSONObject(raw).optString("error",raw)}"); parseText(raw) }
    }
    private fun parseText(raw:String):String { val root=JSONObject(raw); val out=root.optJSONArray("output") ?: return root.optString("output_text","Sin respuesta") ; val sb=StringBuilder(); for(i in 0 until out.length()){ val item=out.optJSONObject(i); val content=item?.optJSONArray("content") ?: continue; for(j in 0 until content.length()){ val c=content.optJSONObject(j); if(c?.optString("type")=="output_text") sb.append(c.optString("text")) } }; return sb.toString().trim().ifBlank{"Sin respuesta"} }
    private suspend fun extractMemory() = withContext(Dispatchers.IO) {
        try {
            val recent=messages.takeLast(10).joinToString("\n") { "${it.role}: ${it.text}" }
            val prompt="Extrae SOLO hechos personales estables o preferencias que el usuario haya revelado explícitamente y que puedan mejorar futuras respuestas. Devuelve JSON array de strings, máximo 5. No guardes contraseñas, API keys, datos financieros sensibles, salud, ubicación precisa ni información íntima. Si no hay nada útil devuelve [].\nCONVERSACIÓN:\n$recent"
            val body=JSONObject().put("model","gpt-5.6-luna").put("input",prompt).put("max_output_tokens",400)
            val req=Request.Builder().url("https://api.openai.com/v1/responses").addHeader("Authorization","Bearer $apiKey").addHeader("Content-Type","application/json").post(body.toString().toRequestBody("application/json".toMediaType())).build()
            client.newCall(req).execute().use { r -> if(r.isSuccessful){ val text=parseText(r.body?.string().orEmpty()); val clean=text.substringAfter("[").substringBeforeLast("]","").let{"[$it]"}; val a=JSONArray(clean); val set=memories.toMutableList(); for(i in 0 until a.length()) set.add(a.optString(i)); memories=set.distinct().takeLast(100); persist() } }
        } catch(_:Exception){}
    }
}

@Composable fun PersonalAIApp(vm: AiViewModel = viewModel()) {
    val context=androidx.compose.ui.platform.LocalContext.current; LaunchedEffect(Unit){vm.init(context)}
    var screen by remember { mutableStateOf("chat") }
    MaterialTheme(colorScheme=darkColorScheme()) {
        when(screen){
            "settings" -> SettingsScreen(vm){screen="chat"}
            "memory" -> MemoryScreen(vm){screen="chat"}
            else -> ChatScreen(vm, onSettings={screen="settings"}, onMemory={screen="memory"})
        }
    }
}

@Composable fun ChatScreen(vm:AiViewModel,onSettings:()->Unit,onMemory:()->Unit){
    Scaffold(topBar={TopAppBar(title={Text("Personal AI")},actions={TextButton(onClick=onMemory){Text("🧠")};TextButton(onClick=onSettings){Text("⚙")}})},bottomBar={
        Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically){ OutlinedTextField(value=vm.input,onValueChange={vm.input=it},modifier=Modifier.weight(1f),placeholder={Text("Escribe un mensaje...")},maxLines=4); Spacer(Modifier.width(8.dp)); Button(onClick={vm.send},enabled=!vm.busy){Text(if(vm.busy)"…" else "Enviar")} }
    }){ pad -> Column(Modifier.padding(pad).fillMaxSize()){ if(vm.error!=null) Text(vm.error!!,color=MaterialTheme.colorScheme.error,modifier=Modifier.padding(12.dp)); LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal=12.dp),verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(vertical=12.dp)){items(vm.messages){m->Bubble(m)}} } }
}
@Composable fun Bubble(m:ChatMessage){ Row(Modifier.fillMaxWidth(),horizontalArrangement=if(m.role=="user")Arrangement.End else Arrangement.Start){ Surface(shape=RoundedCornerShape(18.dp),color=if(m.role=="user")MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,modifier=Modifier.widthIn(max=330.dp)){Text(m.text,Modifier.padding(13.dp))} } }

@Composable fun SettingsScreen(vm:AiViewModel,back:()->Unit){ var key by remember(vm.apiKey){mutableStateOf(vm.apiKey)}; Column(Modifier.fillMaxSize().padding(20.dp)){Text("Ajustes",style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(20.dp));Text("API de IA",style=MaterialTheme.typography.titleMedium);Spacer(Modifier.height(8.dp));OutlinedTextField(value=key,onValueChange={key=it},modifier=Modifier.fillMaxWidth(),visualTransformation=PasswordVisualTransformation(),label={Text("OpenAI API key")});Spacer(Modifier.height(12.dp));Text("La clave se guarda localmente en este teléfono. Para una app pública conviene usar un servidor propio y no exponer una clave en el APK.",style=MaterialTheme.typography.bodySmall);Spacer(Modifier.height(20.dp));Button(onClick={vm.saveKey(key);back()}){Text("Guardar")};TextButton(onClick=back){Text("Volver")}}
}
@Composable fun MemoryScreen(vm:AiViewModel,back:()->Unit){ Column(Modifier.fillMaxSize().padding(20.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("Lo que sé de ti",style=MaterialTheme.typography.headlineMedium,modifier=Modifier.weight(1f));TextButton(onClick=back){Text("Volver")}};Spacer(Modifier.height(10.dp));Text("La IA añade recuerdos periódicamente. Puedes borrarlos.",style=MaterialTheme.typography.bodySmall);Spacer(Modifier.height(12.dp));if(vm.memories.isEmpty())Text("Todavía no hay recuerdos aprendidos.") else LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(vm.memories){m->Surface(shape=RoundedCornerShape(12.dp),color=MaterialTheme.colorScheme.surfaceVariant){Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){Text(m,Modifier.weight(1f));TextButton(onClick={vm.deleteMemory(m)}){Text("Borrar")}}}}};Spacer(Modifier.height(12.dp));TextButton(onClick={vm.clearAll}){Text("Borrar toda la memoria y conversación")}}
}
