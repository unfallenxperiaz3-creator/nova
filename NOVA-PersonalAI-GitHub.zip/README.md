# NOVA — Personal AI

Android app tipo ChatGPT con avatar extraterrestre, conversación por texto/voz y memoria personal.

## Compilación en GitHub
1. Sube el contenido a un repositorio de GitHub.
2. Ve a **Actions**.
3. Ejecuta **Build NOVA APK**.
4. Descarga el artefacto **NOVA-debug-apk**.
5. Dentro encontrarás `app-debug.apk`.

## Funciones V1
- Avatar alienígena visible encima de la conversación.
- Animación suave del avatar.
- Chat por texto.
- Reconocimiento de voz de Android.
- Respuestas habladas mediante Text-to-Speech.
- Memoria local persistente.
- Detección inicial de frases como “me gusta…”, “prefiero…”, “mi coche…”, etc.
- Memoria editable/borrable.
- OpenAI Responses API.

## API key
Configúrala desde ⚙️. No la subas a GitHub.

## Producción
Para distribuir la app a otras personas, sustituye la llamada directa desde Android por un backend propio que proteja las credenciales y controle el consumo.
